<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="#">
    <img src="leadermaker.png" width="30" height="30" alt="">
  </a>
 
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="navbar-brand" href="index.php">Home </a>
      </li>
      <li class="nav-item active">
        <a class="navbar-brand" href="about.php">About </span></a>
      </li>
      <li class="nav-item active">
        <a class="navbar-brand" href="contact-us.php">Contact </span></a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="navbar-brand dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
        login
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="voter-loginpage.php" style="background-color:grey;">voter</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="signin.php" style="background-color:grey;">Admin</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="partylogin-page.php" style="background-color:grey;">Party</a>
          <div class="dropdown-divider"></div>
        </div>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
 
 
 
 
