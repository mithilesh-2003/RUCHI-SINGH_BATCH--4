<?php
$a=$_POST['name'];
$b=$_POST['password'];


$conn=mysqli_connect("localhost","root","","php1db");

$sel="select *from partylogin where username	='$a' or password='$b'";
$rel=mysqli_query($conn,$sel);
$check=mysqli_fetch_array($rel,MYSQLI_BOTH);
if($check['username']==$a)
{
  if($check['password']==$b){
   // echo "login ok";
   header("location:dataTable2.php");
  }else{
    echo "worng password";
  }
}else{
  echo "worng username";
}


?>