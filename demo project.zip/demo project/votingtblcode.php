<?php

$a=$_POST['bjp'];
$b=$_POST['inc'];
$c=$_POST['aap'];
$d=$_POST['bsp'];
$e=$_POST['sp'];
$f=$_POST['tmc'];
$g=$_POST['ncp'];
$h=$_POST['rjd'];
$i=$_POST['jdu'];
$j=$_POST['dmk'];
$k=$_POST['cpi'];
$l=$_POST['ss'];
$m=$_POST['nota'];

// $date=date_default_timezone_set("asia/kolkata");



$conn=mysqli_connect("localhost","root","","php1db");
$ins="INSERT INTO `voat` (`id`, `bjp`, `inc`, `aap`, `bsp`, `sp`, `tmc`, `ncp`, `rjd`, `jdu`, `dmk`, `cpi`, `ss`, `nota`)
 VALUES (NULL, '$a', '$b', '$c', '$d', '$e', '$f', '$g', '$h', '$i', '$j', '$k', '$l', '$m');";
if(mysqli_query($conn,$ins))
{
    header("location:index.php");
}
else
{
    echo"not voat";
}


?>