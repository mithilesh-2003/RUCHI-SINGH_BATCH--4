<html>
    <head>
       
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" 
  integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
  integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" 
  integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
 integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
 
  <link rel="stylesheet" href="stylesheet.css">
  <title>
    Voting Page
</title>
        <style>

        </style>
    </head>
    <body>
        <div id="headerSection">
            <h1>Onilne Voting System</h1> 
        </div>
        <hr>
        <div id="headerSection">
        <?php include 'nav.php'?>
      </div>
          <br/><br/>
          
        <div id="bodySection">
            <div class="container">
                <h5>Voting Page</h5>
                <br/><br/>
               

                 <div class="row">
                    <div class="col">
                        <form action="votingtblcode.php" method="post">
                        <table class="table">
                            <tr>
                                <th>srno</th>
                            <th>name</th>
                            <th>symbol</th>
                            <th>VOTE</th>
                            <th>Botton</th>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Bhartiya Janta Party(BJP)</td>
                                <td><img src="symbol.jpeg" alt="" width="20%"></td>
                                <td><input type="text"name="bjp" /></td>
                                <td><button >Submit</button></td>
                            </tr>
                         
                            <tr>
                                <td>2</td>
                                <td>Indian National Congress(INC)</td>
                                <td><img src="sym2.jpeg" alt="" width="20%"></td>
                                <td><input type="text" name="inc"/></td>
                                <td><button >Submit</button></td>
                             </tr>
                         
                            <tr>
                                <td>3</td>
                                <td>Aam Admi Party(AAP)</td>
                                <td><img src="sym3.jpeg" alt="" width="20%"></td>
                                <td><input type="text"name="aap" /></td>
                                <td><button >Submit</button></td>
                                
                            </tr>
                         
                            <tr>
                                <td>4</td>
                                <td>Bahujan Samajvadi Party(BSP)</td>
                                <td><img src="sym5.jpeg" alt="" width="20%"></td>
                                <td><input type="text" name="bsp"/></td>
                                <td><button >Submit</button></td>
                               </tr>

                                <tr>
                                  <td>5</td>
                                  <td>Samajvadi Party(SP)</td>
                                 <td><img src="sym4.jpeg" alt="" width="20%"></td>
                                 <td><input type="text" name="sp"/></td>
                                   <td><button name="sp">Submit</button></td>
                                   </tr>

                                   <tr>
                                   <td>6</td>
                                    <td>Trinamool Congress(TMC)</td>
                                    <td><img src="TMC.jpeg" alt="" width="20%"></td>
                                    <td><input type="text" name="tmc"/></td>
                                    <td><button name="tmc">Submit</button></td>
                                   </tr>

                                   <tr>
                                    <td>7</td>
                                     <td>National Congress Party(NCP)</td>
                                     <td><img src="NCP.jpeg" alt="" width="20%"></td>
                                     <td><input type="text" name="ncp"/></td>
                                     <td><button name="ncp">Submit</button></td>
                                    </tr>

                                    <tr>
                                      <td>7</td>
                                       <td>Rastriya Janta Dal(RJD)</td>
                                       <td><img src="RJD.jpeg" alt="" width="20%"></td>
                                       <td><input type="text" name="rjd"/></td>
                                       <td><button name="rjd">Submit</button></td>
                                      </tr>

                                      <tr>
                                        <td>8</td>
                                         <td>Janes Defence Upgrades(JDU)</td>
                                         <td><img src="JDU.jpeg" alt="" width="20%"></td>
                                         <td><input type="text" name="jdu"/></td>
                                         <td><button name="jdu">Submit</button></td>
                                        </tr>

                                        <tr>
                                          <td>9</td>
                                           <td>Dravdian Progressive Federation(DMK)</td>
                                           <td><img src="DMK.jpeg" alt="" width="20%"></td>
                                           <td><input type="text" name="dmk"/></td>
                                           <td><button name="dmk">Submit</button></td>
                                          </tr>

                                          <tr>
                                            <td>10</td>
                                             <td>Communist Party of India(CPI)</td>
                                             <td><img src="sym6.jpeg" alt="" width="20%"></td>
                                             <td><input type="text" name="cpi"/></td>
                                             <td><button name="cpi">Submit</button></td>
                                            </tr>

                                            <tr>
                                              <td>11</td>
                                               <td>Shiv Sena(SS)</td>
                                               <td><img src="SS.jpeg" alt="" width="20%"></td>
                                               <td><input type="text" name="ss"/></td>
                                               <td><button name="ss">Submit</button></td>
                                              </tr>
                                              <tr>
                                              <td>12</td>
                                               <td>NOTA</td>
                                               <td>Vote to No-one</td>
                                               <td><input type="text" name="nota"/></td>
                                               <td><button name="nota">Submit</button></td>
                                              </tr>
                         
                        </table>
</form>
                    </div>
                 </div>















            
            </div>
















        </div>
       
    </body>
</html>