<?php
$a=$_POST['email'];
$b=$_POST['password'];
$conn=mysqli_connect("localhost","root","","php1db");
$ins="insert into sinup(username,password)values('$a','$b')";
if(mysqli_query($conn,$ins)){
    $ins2="insert into adminlogin(username,password)values('$a','$b')";
    if(mysqli_query($conn,$ins2)){
      // echo "data store"; 
      header("location:adminlogin.php");
    }
   
}

?>