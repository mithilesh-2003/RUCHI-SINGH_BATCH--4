                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

        <link rel="stylesheet" href="stylesheet.css">
        <title>Online Voting System-Contact</title>
        <style>
            
            #main
            {
                height: 600px;
                width: 1200px;
            margin-left: 120px;
            }
            #m1
            {
                height: 550px;
                width: 350px;
                margin-left: 30px;
                margin-right:20px;
                float: left;
                margin-top:20px;
                margin-bottom:20px;
                text-align: center;
            }
            #m2
            {
                height: 550px;
                width: 350px;
                margin: 20px;
                margin-top:30px;
                float: left;
                text-align: center;
            }
            #m3
            {
                height: 550px;
                width: 350px;
                margin: 20px;
                margin-top:30px;
                float: left;
                text-align: center;
            }
        </style>

    </head>
    <body>
        <div id="headerSection">
            <h1>Online Voting System</h1>
        </div>
        <hr>
        <div id="headerSection">
        <?php include 'nav.php'?>
            </div>
       
        <div id="bodySection">
            <h2>Contact Us</h2>
        <div id="main">
    <div id="m1">
        <img src="whatsapp.png" class="rounded-circle img-thumbnail"
         style="height:50px; width:50px;">
         <h5>whatsapp</h5>
         <p>Connect with us to get more updated.</p>
         <p>We help you to knwoing upcoming <br>elections and we will notify you.</p>
         <p><a href="https://whatsapp.com">Click here to connect</a></p>
    </div>
    <div id="m2">
        <img src="telegram.png" type="icon" style="height:50px; width:50px;">
        <h5>Telegram</h5>
        <p>Tell us, how we can help you!</p>
        <p>Here is our telegram account</p>
        <p><a href="https://telegram.com">Please click</a></p>

    </div>
    <div id="m3">
        <img src="twit.png" type="icon" style="height:50px; width:50px;">
        <h5>Twitter</h5>
        <p>Connect with world.</p>
        <p>This is our official twitter handle</p>
        <p><a href="https://twitter.com">Click here</a></p>
    </div>
</div>
<div class="col-sm-12py-4"><h2 style="background-color:orange; color:white; height:60px;">@copyright developed by Ruchi Singh</h2></div>
</div>
    </body>
</html>