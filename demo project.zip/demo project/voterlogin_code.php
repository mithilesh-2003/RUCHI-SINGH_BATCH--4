<?php
$a=$_POST['Adhar'];

$conn=mysqli_connect("localhost","root","","php1db");

$sel="select * from  voterlogin where adhar='$a'";
$rel=mysqli_query($conn,$sel);
$check=mysqli_fetch_array($rel,MYSQLI_BOTH);
if($check['adhar']==$a)
{ 
   // echo "data store";
   header("location:votingpage.php");
}
else{


    header("location:voter-loginpage.php");
    
}

/*if(mysqli_query($conn,$ins))
{
    header("location:votingpage.php");
}
else(
    echo "data not store";
)
*/
?> 